---
layout:     authors
collection: authors
name:       "Julien Letessier"
jobtitle:   "Principal Engineer"
portrait:   "/images/portraits/julien-letessier.jpg"
---

I’m a software geek: I build things with code, like web applications, platform tools, search engines, or even tiny crypto utilities.
I’ve previously had fun as an engineer, scientist, architect, manager, and start-up founder.

This days I mostly help other people building software here at Deliveroo!
