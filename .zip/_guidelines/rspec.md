---
layout:     guidelines
title:      "RSpec"
subtitle:   "Guidelines for writing Ruby tests with RSpec"
collection: guidelines
---

## Table of Contents
{:.no_toc}

1. Automatic Table of Contents Here
{:toc}

Empty for now.
