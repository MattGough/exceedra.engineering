---
layout:     guidelines
title:      "Java & Android"
subtitle:   "Guidelines on developing for Android with Java"
collection: guidelines
---

## Table of Contents
{:.no_toc}

1. Automatic Table of Contents Here
{:toc}

Contents go here.
