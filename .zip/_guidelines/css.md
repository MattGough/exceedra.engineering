---
layout:     guidelines
title:      "CSS and SCSS"
subtitle:   "Guidelines on writing CSS and SCSS"
collection: guidelines
---

## Table of Contents
{:.no_toc}

1. Automatic Table of Contents Here
{:toc}

Empty for now
